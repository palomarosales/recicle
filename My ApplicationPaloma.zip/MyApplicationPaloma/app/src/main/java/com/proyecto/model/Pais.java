package com.proyecto.model;

public class Pais {
    private String nombre;
    private String capital;
    private String bandera;

    public Pais (){
    }

    public Pais (String nombre, String capital,String bandera){
        this.nombre=nombre;
        this.capital=capital;
        this.bandera=bandera;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public String getBandera() {
        return bandera;
    }
    public void setBandera(String bandera) {
        this.bandera = bandera;
    }


    public String getCapital() {
        return capital;
    }
    public void setCapital(String capital) {
        this.capital = capital;
    }


}



